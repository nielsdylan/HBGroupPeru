<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SedeTurn extends Model
{
    use HasFactory;
    protected $primaryKey = 'sede_turn_id';
}
