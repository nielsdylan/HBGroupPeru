@extends('backend.private')
@section('title','dashboard')
@section('content')
    <h1>soy el dashboard</h1>
@endsection
