<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="">
<meta name="author" content="Niels Q.P.">
<meta name="keywords" content="HB Group Perú">

<!-- ANALYTICS -->

<!-- ANALYTICS -->

<?php if (!empty($configuracion['og_title'])): ?>
<meta property="og:url"                content="{{ url('/') }}" />
<meta property="og:type"               content="article" />
<meta property="og:title"              content="HB Group Perú" />
<meta property="og:description"        content="" />
<meta property="og:image"              content="{{asset('uploads/public/logo_marco.png')}}" />
<?php endif ?>
