<script src="{{asset('assets/js/plugin/fancybox/jquery.fancybox.js')}}"></script>

<script src="{{asset('assets/js/js/bootstrap.min.js')}}"></script>
<!-- jQuery UI -->
{{-- <script src="{{asset('assets/js/js/jquery.nicescroll.js')}}"></script> --}}
<script src="{{asset('assets/js/plugin/jquery-ui-1.12.1.custom/jquery-ui.min.js')}}"></script>
<script src="{{asset('assets/js/js/owl.carousel.js')}}"></script>
<script src="{{asset('assets/js/js/wow.js')}}"></script>
{{-- <script src="{{asset('assets/js/plugin/jquery-ui-touch-punch/jquery.ui.touch-punch.min.js')}}"></script> --}}
<script src="{{asset('assets/js/plugin/fancybox/jquery.fancybox.js?v=2.1.6')}}" type="text/javascript"></script>
<!-- jQuery Scrollbar -->
{{-- <script src="{{asset('assets/js/plugin/jquery-scrollbar/jquery.scrollbar.min.js')}}"></script> --}}
{{-- my js --}}
<script src="{{asset('assets/js/frontend.js')}}"></script>
