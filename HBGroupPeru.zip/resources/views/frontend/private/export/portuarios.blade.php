
<table style="">
    <thead>
    <tr>
        <th style="text-align:center; font-weight: 700;"> DNI </th>
        <th style="text-align:center; font-weight: 700;"> APELLIDO PATERNO </th>
        <th style="text-align:center; font-weight: 700;"> APELLIDO MATERNO </th>
        <th style="text-align:center; font-weight: 700;"> NOMBRE </th>
        <th style="text-align:center; font-weight: 700;"> EMAIL </th>
        <th style="text-align:center; font-weight: 700;"> CELULAR </th>
    </tr>
    </thead>
    <tbody>
    </tbody>
</table>
