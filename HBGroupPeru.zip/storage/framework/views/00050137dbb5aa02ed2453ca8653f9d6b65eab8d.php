<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<title>Login</title>
	<meta content='width=device-width, initial-scale=1.0, shrink-to-fit=no' name='viewport' />
	<link rel="icon" href="<?php echo e(asset('uploads/public/logo_snc.png')); ?>" type="image/x-icon">

	<!-- Fonts and icons -->
	<script src="<?php echo e(asset('assets/js/plugin/webfont/webfont.min.js')); ?>"></script>
	<script>
		WebFont.load({
			google: {"families":["Open+Sans:300,400,600,700"]},
			custom: {"families":["Flaticon", "Font Awesome 5 Solid", "Font Awesome 5 Regular", "Font Awesome 5 Brands"], urls: ["<?php echo e(asset('assets/css/fonts.css')); ?>"]},
			active: function() {
				sessionStorage.fonts = true;
			}
		});
	</script>
    <script type="text/javascript"> var url="<?php echo e(url('').'/'); ?>"; </script>
    
	<!-- CSS Files -->
	<link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('assets/css/azzara.min.css')); ?>">
</head>
<body class="login">
	<div class="wrapper wrapper-login">
		<div class="container container-login animated fadeIn">
			<h3 class="text-center">Inicia session</h3>
            <form action="" method="POST" data-login="session-start">
                <input type="hidden" name="token" value="<?php echo e(csrf_token()); ?>">
                <div class="login-form">
                    <div class="form-group">
                        <label for="username" class="placeholder"><b>Correo</b></label>
                        <input id="username" name="username" type="text" class="form-control" placeholder="ejemplo@ejemplo..." required>
                    </div>
                    <div class="form-group">
                        <label for="password" class="placeholder"><b>Contraseña</b></label>
                        
                        <div class="position-relative">
                            <input id="password" name="password" type="password" class="form-control" required>
                            <div class="show-password">
                                <i class="flaticon-interface"></i>
                            </div>
                        </div>
                    </div>
                    <div class="form-group d-flex justify-content-center">
                        
                            
                            
                        
                        <button type="submit" class="btn btn-primary col-md-5 float-right mt-3 mt-sm-0 fw-bold">Iniciar </button>
                    </div>
                </div>
            </form>

		</div>

		
	</div>
	<script src="<?php echo e(asset('assets/js/core/jquery.3.2.1.min.js')); ?>"></script>
	<script src="<?php echo e(asset('assets/js/plugin/jquery-ui-1.12.1.custom/jquery-ui.min.js')); ?>"></script>
	<script src="<?php echo e(asset('assets/js/core/popper.min.js')); ?>"></script>
	<script src="<?php echo e(asset('assets/js/core/bootstrap.min.js')); ?>"></script>
	<script src="<?php echo e(asset('assets/js/ready.js')); ?>"></script>
    <script>
        $(document).on('submit','[data-login="session-start"]',function (e) {
            e.preventDefault();
            var data = $(this).serialize();
            $.ajax({
                method: 'POST',
                headers: {'X-CSRF-TOKEN': $('[name="token"]').val()},
                url: url+'login/session',
                dataType: 'json',
                data: data,
            }).done(function (response) {
                if (response.status == 200) {
                    location.href = '<?php echo route('perfil.index'); ?>';
                }else{
                    var placementFrom = 'top';
                    var placementAlign = 'center';
                    var state = 'danger';
                    var style = 'withicon';
                    var content = {};

                    content.message = 'Ingrese correctamente los datos para la session para HB Group Perú';
                    content.title = 'Session';
                    // if (style == "withicon") {
                    //     content.icon = 'fas fa-times';
                    // } else {
                    //     content.icon = 'none';
                    // }
                    content.icon = 'fas fa-times';
                    content.url = url+'hbgroupp_web';
                    content.target = '_blank';

                    $.notify(content,{
                        type: state,
                        placement: {
                            from: placementFrom,
                            align: placementAlign
                        },
                        time: 1000,
                        delay: 0,
                    });

                    setTimeout(function(){
                        $('[data-notify="dismiss"]').click();
                    }, 3000);
                }
            }).fail(function () {
                // alert("Error");
            });

        });
    </script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\HBGroupPeru\resources\views/frontend/login.blade.php ENDPATH**/ ?>