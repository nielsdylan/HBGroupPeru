<div class="main-header" data-background-color="purple">
    <nav class="navbar navbar-expand-lg bg-primary">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">HBGROUPP</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item ">
                        <div class="dropdown">
                            <a class="btn btn-primary " href="<?php echo e(route('dashboard')); ?>">
                                Dashboard
                            </a>

                        </div>
                        
                    </li>
                    <li class="nav-item ">
                        <div class="dropdown">
                            <button class="btn btn-primary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="fas fa-chalkboard-teacher"></i>
                                Administrador
                            </button>
                            <div class="dropdown-menu animated fadeIn" aria-labelledby="dropdownMenuButton">
                                <a class="dropdown-item" href="<?php echo e(route('setting')); ?>"><i class="fas fa-cog"></i> Configuraci&oacute;n</a>
                                <a class="dropdown-item" href="<?php echo e(route('group.index')); ?>"><i class="
                                    fas fa-users
                                    "></i> Grupos</a>
                                <a class="dropdown-item" href="<?php echo e(route('list_user')); ?>"><i class="fas fa-user-plus"></i> Usuario</a>
                            </div>
                        </div>
                    </li>
                    <li class="nav-item">
                        <div class="dropdown">
                            <button class="btn btn-primary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="fas fa-globe"></i>
                                Landing
                            </button>
                            <div class="dropdown-menu animated fadeIn" aria-labelledby="dropdownMenuButton">
                                <a class="dropdown-item" href="<?php echo e(route('slider.index')); ?>"><i class="fas fa-images"></i> Sliders</a>
                                <a class="dropdown-item" href="<?php echo e(route('business.index')); ?>"><i class="fas fa-list"></i> Empresas</a>
                                <a class="dropdown-item" target="_blank" href="<?php echo e(route('index')); ?>"><i class="fas fa-globe-americas"></i> Vista previa</a>
                            </div>
                        </div>
                    </li>
                </ul>
                <ul class="navbar-nav topbar-nav ml-md-auto">
                    <li class="nav-item">
                        <div class="dropdown">
                            <button class="btn btn-primary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="fas fa-user-alt"></i>

                            </button>
                            <div class="dropdown-menu animated fadeIn" aria-labelledby="dropdownMenuButton">


                                <a class="dropdown-item" href="<?php echo e(route('logout.logout')); ?>"><i class="fas fa-power-off"></i> Cerrar session</a>
                            </div>
                        </div>
                    </li>
                </ul>

            </div>
        </div>

    </nav>
</div>
<?php /**PATH C:\xampp\htdocs\HBGroupPeru\resources\views/backend/private/layout/menu.blade.php ENDPATH**/ ?>