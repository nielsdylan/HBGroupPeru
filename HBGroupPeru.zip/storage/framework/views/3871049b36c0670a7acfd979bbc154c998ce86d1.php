<?php $__env->startSection('title','HB Group Perú'); ?>
<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="page-inner animated fadeInUp">
        <div class="page-header">
            <ul class="breadcrumbs">
                <li class="nav-home">
                    <a href="<?php echo e(route('dashboard')); ?>">
                        <i class="flaticon-home"></i>
                    </a>
                </li>
                <li class="separator">
                    <i class="flaticon-right-arrow"></i>
                </li>
                <li class="nav-item">
                    <a href="<?php echo e(route('setting')); ?>">Administrador</a>
                </li>
                <li class="separator">
                    <i class="flaticon-right-arrow"></i>
                </li>
                <li class="nav-item">
                    <a href="<?php echo e(route('setting')); ?>">Configuración</a>
                </li>
            </ul>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="card animated fadeInUp">
                    <div class="card-header">
                        <h4 class="card-title">Configuración</h4>
                    </div>
                    <div class="card-body">
                        <form action="<?php echo e(route('setting.save', $configurations)); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="title">Titulo</label>
                                        <div class="input-group">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text">
                                                <i class="fa fa-heading"></i>
                                                </span>
                                            </div>
                                            <input type="text" id="title" class="form-control" name="title" value="<?php echo e($configurations ? $configurations->title : ''); ?>" required>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="email">Correo</label>
                                        <div class="input-group">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text">
                                                <i class="far fa-envelope"></i>
                                                </span>
                                            </div>
                                            <input id="email" class="form-control" type="email" name="email" value="<?php echo e($configurations ?$configurations->email : ''); ?>" required>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="mobile">Mobile</label>
                                        <div class="input-group">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text">
                                                <i class="fas fa-mobile-alt"></i>
                                                </span>
                                            </div>
                                            <input id="mobile" class="form-control" type="text" name="mobile" value="<?php echo e($configurations ?$configurations->mobile :''); ?>" >
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="telephone">Telfono</label>
                                        <div class="input-group">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text">
                                                <i class="fas fa-phone"></i>
                                                </span>
                                            </div>
                                            <input id="telephone" class="form-control" type="text" name="telephone" value="<?php echo e($configurations ? $configurations->telephone:''); ?>" >
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="sender">Remitente</label>
                                        <div class="input-group">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text">
                                                <i class="fas fa-reply"></i>
                                                </span>
                                            </div>
                                            <input id="sender" class="form-control" type="email" name="sender" value="<?php echo e($configurations ?$configurations->sender :''); ?>" required>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="whatsapp">Whatsapp</label>
                                        <div class="input-group">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text">
                                                <i class="fab fa-whatsapp"></i>
                                                </span>
                                            </div>
                                            <input id="whatsapp" class="form-control" type="text" name="whatsapp" value="<?php echo e($configurations ?$configurations->whatsapp :''); ?>" >
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="facebook">Facebook</label>
                                        <div class="input-group">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text">
                                                <i class="fab fa-facebook-f"></i>
                                                </span>
                                            </div>
                                            <input id="facebook" class="form-control" type="text" name="facebook" value="<?php echo e($configurations ?$configurations->facebook : ''); ?>" >
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="linkedin">Linkedin</label>
                                        <div class="input-group">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text">
                                                <i class="fab fa-linkedin-in"></i>
                                                </span>
                                            </div>
                                            <input id="linkedin" class="form-control" type="text" name="linkedin" value="<?php echo e($configurations ?$configurations->linkedin :''); ?>" >
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="schedule">Horario</label>
                                        <div class="input-group">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text">
                                                <i class="far fa-calendar-alt"></i>
                                                </span>
                                            </div>
                                            <input id="schedule" class="form-control" type="text" name="schedule" value="<?php echo e($configurations ?$configurations->schedule :''); ?>" >
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="direction">Dirección</label>
                                        <div class="input-group">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text">
                                                <i class="fas fa-location-arrow"></i>
                                                </span>
                                            </div>
                                            <input id="direction" class="form-control" type="text" name="direction" value="<?php echo e($configurations ?$configurations->direction :''); ?>" >
                                        </div>

                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12 text-right">
                                    <button type="submit" class="btn btn-primary btn-round"><i class="fa fa-save"></i> Guardar</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.private', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\HBGroupPeru\resources\views/backend/private/configuration/configuration.blade.php ENDPATH**/ ?>