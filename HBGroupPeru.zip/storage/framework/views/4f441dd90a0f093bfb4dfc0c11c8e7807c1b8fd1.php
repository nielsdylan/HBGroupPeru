<script src="<?php echo e(asset('assets/js/plugin/fancybox/jquery.fancybox.js')); ?>"></script>

<script src="<?php echo e(asset('assets/js/js/bootstrap.min.js')); ?>"></script>
<!-- jQuery UI -->

<script src="<?php echo e(asset('assets/js/plugin/jquery-ui-1.12.1.custom/jquery-ui.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/js/owl.carousel.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/js/wow.js')); ?>"></script>

<script src="<?php echo e(asset('assets/js/plugin/fancybox/jquery.fancybox.js?v=2.1.6')); ?>" type="text/javascript"></script>
<!-- jQuery Scrollbar -->


<script src="<?php echo e(asset('assets/js/frontend.js')); ?>"></script>
<?php /**PATH C:\xampp\htdocs\HBGroupPeru\resources\views/frontend/layouts/public/js.blade.php ENDPATH**/ ?>