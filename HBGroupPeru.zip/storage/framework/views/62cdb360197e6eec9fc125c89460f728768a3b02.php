<header>


</header>
<?php /**PATH C:\xampp\htdocs\HBGroupPeru\resources\views/backend/private/layout/header.blade.php ENDPATH**/ ?>