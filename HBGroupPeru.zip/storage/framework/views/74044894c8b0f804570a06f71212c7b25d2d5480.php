<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<title>HB Group Peru</title>
	<meta content='width=device-width, initial-scale=1.0, shrink-to-fit=no' name='viewport' />
	

    <?php echo $__env->make('frontend.layouts.private.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('frontend.layouts.private.js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<body data-background-color="bg3">
	<div class="wrapper">
        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
        <script type="text/javascript"> var url="<?php echo e(url('').'/'); ?>"; </script>
		<div class="main-header" data-background-color="blue"
			>
			<?php echo $__env->make('frontend.layouts.private.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
			<!-- End Navbar -->
		</div>

		<!-- Sidebar -->
		<?php echo $__env->make('frontend.layouts.private.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<!-- End Sidebar -->

		<div class="main-panel">
			<div class="content">
                <?php echo $__env->yieldContent('content'); ?>
			</div>

		</div>

	</div>
</div>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\HBGroupPeru\resources\views/frontend/private.blade.php ENDPATH**/ ?>