<?php $__env->startSection('title','dashboard'); ?>
<?php $__env->startSection('content'); ?>
    <h1>soy el dashboard</h1>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.private', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\hbgroup\hbgroupp\resources\views/backend/private/dashboard.blade.php ENDPATH**/ ?>