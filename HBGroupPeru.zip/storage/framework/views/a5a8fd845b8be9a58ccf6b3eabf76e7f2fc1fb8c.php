<script src="<?php echo e(asset('assets/js/plugin/webfont/webfont.min.js')); ?>"></script>
<script>
    WebFont.load({
        google: {"families":["Open+Sans:300,400,600,700"]},
        custom: {"families":["Flaticon", "Font Awesome 5 Solid", "Font Awesome 5 Regular", "Font Awesome 5 Brands"], urls: ["<?php echo e(asset('assets/css/fonts.css')); ?>"]},
        active: function() {
            sessionStorage.fonts = true;
        }
    });
</script>
<!-- CSS Files -->
<link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/css/azzara.min.css')); ?>">

<!-- CSS Just for demo purpose, don't include it in your project -->
<link rel="stylesheet" href="<?php echo e(asset('assets/css/demo.css')); ?>">

<link rel="stylesheet" href="<?php echo e(asset('assets/css/private.css')); ?>">
<?php /**PATH C:\xampp\htdocs\hbgroup\hbgroupp\resources\views/backend/private/layout/css.blade.php ENDPATH**/ ?>