<div class="sidebar">

    <div class="sidebar-background"></div>
    <div class="sidebar-wrapper scrollbar-inner">
        <div class="sidebar-content">
            <div class="user">
                <div class="avatar-sm float-left mr-2">
                    <?php if(session('hbgroup')['image']): ?>
                        <img src="<?php echo e(asset('assets/img/user/'.session('hbgroup')['image'])); ?>" alt="..." class="avatar-img rounded-circle">
                    <?php else: ?>
                        <img src="<?php echo e(asset('assets/img/profile.jpg')); ?>" alt="..." class="avatar-img rounded-circle">
                    <?php endif; ?>

                </div>
                <div class="info">
                    <a  href="<?php echo e(route('perfil.index')); ?>" >
                        <span>
                            <?php echo e(session('hbgroup')['name']); ?>

                            <span class="user-level"><?php echo e(session('hbgroup')['group']); ?></span>
                        </span>
                    </a>
                    <div class="clearfix"></div>

                </div>
            </div>
            <ul class="nav">
                <?php if(session('hbgroup')['group_id'] == 1 || session('hbgroup')['group_id'] == 5): ?>
                <li class="nav-item">
                    <a data-toggle="collapse" href="#cours">
                        <i class="fas fa-server"></i>
                        <p>Académico</p>
                        <span class="caret"></span>
                    </a>
                    <div class="collapse" id="cours">
                        <ul class="nav nav-collapse">
                            <li>
                                <a href="<?php echo e(route('cursos.index')); ?>">
                                    <span class="sub-item">Cursos</span>
                                </a>
                            </li>
                            <li>
                                <a href="<?php echo e(route('participantes.index')); ?>">
                                    <span class="sub-item">Participantes</span>
                                </a>
                            </li>
                            <li>
                                <a href="<?php echo e(route('asignatura.index')); ?>">
                                    <span class="sub-item">Asignatura</span>
                                </a>
                            </li>
                            <li>
                                <a href="<?php echo e(route('programa.index')); ?>">
                                    <span class="sub-item">Programa</span>
                                </a>
                            </li>
                        </ul>
                    </div>
                </li>
                <?php endif; ?>

                <?php if(session('hbgroup')['group_id'] == 1): ?>
                <li class="nav-item">
                    <a data-toggle="collapse" href="#sede-turn">
                        <i class="far fa-building"></i>
                        <p>Sedes y turnos</p>
                        <span class="caret"></span>
                    </a>
                    <div class="collapse" id="sede-turn">
                        <ul class="nav nav-collapse">
                            <li>
                                <a href="<?php echo e(route('sede-turno.index')); ?>">
                                    <span class="sub-item">Sedes y Turnos</span>
                                </a>
                            </li>
                            <li>
                                <a href="<?php echo e(route('sede.index')); ?>">
                                    <span class="sub-item">Sedes</span>
                                </a>
                            </li>
                            <li>
                                <a href="<?php echo e(route('turno.index')); ?>">
                                    <span class="sub-item">Turnos</span>
                                </a>
                            </li>


                        </ul>
                    </div>
                </li>
                <?php endif; ?>


            </ul>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\HBGroupPeru\resources\views/frontend/layouts/private/sidebar.blade.php ENDPATH**/ ?>