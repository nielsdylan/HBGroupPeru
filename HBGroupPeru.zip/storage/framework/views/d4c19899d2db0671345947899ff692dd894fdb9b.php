<?php if($configurations->whatsapp): ?><a href="https://wa.me/+51<?php echo e($configurations->whatsapp); ?>?text=Mi consulta es..." target="_blank" id="whatsapp-floot" class="btn-whatsapp-link"><i class="fab fa-whatsapp"></i></a><?php endif; ?>
<a href="#" id="back-to-top" class="btn btn-lg btn-back-top"><i class="fa fa-angle-up"></i></a>
<section id="footer">
    <div class="pre-footer">
        <div class="container">
            <div class="row">
                <div class="col-md-4 text-center">
                    <div class="row">
                        <div class="col-md-12">
                            <img src="<?php echo e(asset('uploads/public/logo_snc.png')); ?>" width="140" class="img-footer">
                        </div>
                        <div class="col-md-12 pt-3 text-center">
                            <h3> <strong>HB Group Perú</strong></h3>
                        </div>
                    </div>

                </div>
                <div class="col-md-4 ">
                    <h6 class="text-white ">SITIO</h6>
                    <ul class="list-unstyled color-list">
                        <li>
                            <a href="<?php echo e(url('/')); ?>" class="text-footer"><i class="fa fa-angle-right"></i> INICIO</a>
                        </li>
                        <li>
                            <a href="<?php echo e(url('/nosotros')); ?>" class="text-footer"><i class="fa fa-angle-right"></i> NOSOTROS</a>
                        </li>

                        <li>
                            <a href="<?php echo e(url('/servicios')); ?>" class="text-footer"><i class="fa fa-angle-right"></i> SERVICIOS</a>
                        </li>

                        <li>
                            <a href="<?php echo e(url('/contacto')); ?>" class="text-footer"><i class="fa fa-angle-right"></i> Contacto</a>
                        </li>
                    </ul>
                </div>
                <div class="col-md-4">
                    <h6 class="text-white">CONTACTO</h6>
                    <ul class="list-unstyled color-list">
                        <li>
                            <ul class="list-unstyled">
                                <?php if($configurations->direction): ?>
                                    <li><span class="text-footer"><i class="fas fa-map-marker-alt text-footer"></i> <?php echo e($configurations->direction); ?></span></li>
                                <?php endif; ?>
                                <?php if($configurations->whatsapp): ?>
                                    <li><span class="text-footer"><i class="fab fa-whatsapp text-footer"></i> <?php echo e($configurations->whatsapp); ?></span></li>
                                <?php endif; ?>
                                <?php if($configurations->telephone): ?>
                                    <li><span class="text-footer"><i class="fa fa-phone text-footer"></i> <?php echo e($configurations->telephone); ?></span></li>
                                <?php endif; ?>
                                <?php if($configurations->telephone): ?>
                                    <li><span class="text-footer"><i class="fa fa-envelope text-footer"></i> <?php echo e($configurations->email); ?></span></li>
                                <?php endif; ?>

                            </ul>
                        </li>
                    </ul>
                    <div id="redes" >
                        <ul class="list-inline ml-5 d-none d-sm-none d-lg-block d-md-block">
                            <li class="list-inline-item">
                                <?php if($configurations->facebook): ?>
                                <a class="facebook pr-3 text-white" href="<?php echo e($configurations->facebook); ?>" target="_blank"><i class="fab fa-facebook-f"></i></a>
                                <?php endif; ?>
                                <?php if($configurations->linkedin): ?>
                                <a class="text-white" href="<?php echo e($configurations->linkedin); ?>" target="_blank"><i class="fab fa-linkedin-in"></i></a>
                                <?php endif; ?>
                            </li>
                        </ul>
                        <ul class="list-inline text-center d-block d-sm-block d-lg-none d-md-none">
                            <li class="list-inline-item">
                                <?php if($configurations->facebook): ?>
                                <a class="facebook pr-3 text-white" href="<?php echo e($configurations->facebook); ?>" target="_blank"><i class="fab fa-facebook-f"></i></a>
                                <?php endif; ?>
                                <?php if($configurations->linkedin): ?>
                                <a href="<?php echo e($configurations->linkedin); ?>" class="text-white" target="_blank"><i class="fab fa-linkedin-in"></i></a>
                                <?php endif; ?>
                            </li>

                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="footer-copy">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-12 copyright_text wow fadeInUp animated">
                    <div class="d-none d-lg-block text-white">
                        <center><span>&copy; <?php echo e(date("Y")); ?> HBGroupp - Todos los derechos reservados. </center>
                    </div>
                    <div class="d-block d-lg-none text-white">
                        <center><span>&copy; <?php echo e(date("Y")); ?>  HBGroupp - Todos los derechos reservados.</span></center>
                    </div>
                </div>
            </div>
        </div>

    </div>

</section>
<?php /**PATH C:\xampp\htdocs\HBGroupPeru\resources\views/frontend/layouts/public/footer.blade.php ENDPATH**/ ?>