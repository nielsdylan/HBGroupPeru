<section class="header">
    <div class="top-nav">
        <div class="container">
            <div class="row">
                <?php if($configurations->schedule): ?>
                    <div class="col-md-6 d-none d-md-block" align="left">
                        <ul class="list-inline mb-0">
                                <a href="<?php echo e(url('/')); ?>" class="list-inline-item text-white"><i class="far fa-clock"></i> <?php echo e($configurations->schedule); ?></a>
                        </ul>
                    </div>
                <?php endif; ?>

                <div class="col-md-6 d-none d-md-block" align="right">
                    <ul class="list-inline mb-0">
                        <?php if($configurations->telephone): ?>
                        <a href="tel:+51 <?php echo e($configurations->telephone); ?>" class="list-inline-item text-white"><i class="fa fa-phone"></i> (+51) 53 474805</a>
                        <?php endif; ?>
                        <?php if($configurations->whatsapp): ?>
                        <a href="https://wa.me/+51<?php echo e($configurations->whatsapp); ?>?text=" target="_blank" class="list-inline-item text-white"><i class="fab fa-whatsapp text-white"></i> <?php echo e($configurations->whatsapp); ?></a>
                        <?php endif; ?>

                        

                        

                        <a href="<?php echo e(route('autentication')); ?>" target="_blank" class="list-inline-item icon text-white"><i class="fas fa-user-graduate text-white"></i> Aula virtual</a>

                    </ul>
                </div>
            </div>
        </div>
        <div class="col-md-12 d-block d-md-none pt-2" align="center">
            <?php if($configurations->schedule): ?>
                <div class="col-md-12">
                    <a href="<?php echo e(url('/')); ?>" class="list-inline-item text-white"><i class="far fa-clock"></i> <?php echo e($configurations->schedule); ?></a>
                </div>
            <?php endif; ?>
            <ul class="list-inline mb-0">
                <?php if($configurations->telephone): ?>
                <a href="tel:992 933 603" class="list-inline-item text-white"><i class="fa fa-phone"></i> 946877806</a>
                <?php endif; ?>
                <?php if($configurations->whatsapp): ?>
                <a href="https://wa.me/992933603?text=" target="_blank" class="list-inline-item text-white"><i class="fab fa-whatsapp text-white"></i> 946877806</a>
                <?php endif; ?>
                
                <a href="<?php echo e(route('autentication')); ?>" target="_blank" class="list-inline-item icon text-white"><i class="fas fa-user-graduate text-white"></i> Aula virtual</a>
            </ul>
        </div>
    </div>
</section>



<nav id="menu_navbar" class="navbar navbar-expand-lg navbar-light bg-light text-white bg-dark">
    <div class="container">
        <a class="navbar-brand d-none d-sm-none d-lg-block d-md-block text-white pt-2 pb-2" href="<?php echo e(url('/')); ?>">
            
            <img src="<?php echo e(asset('uploads/public/logo_snc.png')); ?>" class="img-footer"height="50"> HB GROUP PERÚ
        </a>

        <a class="navbar-brand d-block d-sm-block d-lg-none d-md-none text-white mr-0 ml-3" href="<?php echo e(url('/')); ?>">
            
            <img src="<?php echo e(asset('uploads/public/logo_snc.png')); ?>" class="img-footer"height="50">
            
        </a>
        <button class="navbar-toggler mr-4 " type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav mx-auto">
                <li class="nav-item <?php echo e(request()->routeIs('index') ? 'active' : ''); ?>">
                    <a class="nav-link text-white" href="<?php echo e(url('/')); ?>">INICIO <span class="sr-only">(current)</span></a>
                </li>
                <li class="nav-item <?php echo e(request()->routeIs('us') ? 'active' : ''); ?>">
                    <a class="nav-link text-white" href="<?php echo e(url('/nosotros')); ?>">NOSOTROS</a>
                </li>
                <li class="nav-item <?php echo e(request()->routeIs('services') ? 'active' : ''); ?>">
                    <a class="nav-link text-white" href="<?php echo e(url('/servicios')); ?>">SERVICIOS</a>
                </li>
                <li class="nav-item <?php echo e(request()->routeIs('contact') ? 'active' : ''); ?>">
                    <a class="nav-link text-white" href="<?php echo e(url('/contacto')); ?>">CONTACTO</a>
                </li>
            </ul>
        </div>
    </div>
</nav>
<?php /**PATH C:\xampp\htdocs\HBGroupPeru\resources\views/frontend/layouts/public/menu.blade.php ENDPATH**/ ?>