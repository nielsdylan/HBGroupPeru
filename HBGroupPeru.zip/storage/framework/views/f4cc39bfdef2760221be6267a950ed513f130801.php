

<script src="<?php echo e(asset('assets/js/js/bootstrap.min.js')); ?>"></script>
<!-- jQuery UI -->
<script src="<?php echo e(asset('assets/js/plugin/jquery-ui-1.12.1.custom/jquery-ui.min.js')); ?>"></script>


<!-- jQuery Scrollbar -->
<script src="<?php echo e(asset('assets/js/plugin/jquery-scrollbar/jquery.scrollbar.min.js')); ?>"></script>

<script src="<?php echo e(asset('assets/js/frontend.js')); ?>"></script>
<?php /**PATH C:\xampp\htdocs\hbgroup\hbgroupp\resources\views/frontend/layouts/public/js.blade.php ENDPATH**/ ?>