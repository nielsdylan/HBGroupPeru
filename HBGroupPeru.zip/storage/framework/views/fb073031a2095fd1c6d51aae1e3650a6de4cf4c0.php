<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="icon" href="<?php echo e(asset('uploads/public/logo_snc.png')); ?>" type="image/x-icon">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <?php echo $__env->make('backend.private.layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('backend.private.layout.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
</head>
<body>
    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
    <script type="text/javascript"> var url="<?php echo e(url('').'/'); ?>"; </script>
    
    <?php echo $__env->make('backend.private.layout.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
    <div class="main-panel content-dashboard">
        <?php echo $__env->yieldContent('content'); ?>
    </div>
    
    
    <?php echo $__env->make('backend.private.layout.js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\HBGroupPeru\resources\views/backend/private.blade.php ENDPATH**/ ?>