<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Prefixe extends Model
{
    use HasFactory;
    protected $primaryKey = 'prefixe_id';
}
