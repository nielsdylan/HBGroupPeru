<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class QuestionsResponse extends Model
{
    use HasFactory;
    protected $primaryKey = 'question_response_id';
}
