$(document).ready(function () {
    if ($(".fancybox").length) {
        $('.fancybox').fancybox({

        });
      }
});
