
<table style="">
    <thead>
    <tr>
        <th style="text-align:center; font-weight: 700;"> DNI </th>
        <th style="text-align:center; font-weight: 700;"> AP. PATERNO </th>
        <th style="text-align:center; font-weight: 700;"> AP. MATERNO </th>
        <th style="text-align:center; font-weight: 700;"> NOMBRES </th>
        <th style="text-align:center; font-weight: 700;"> DETALLE DEL CURSO </th>
        <th style="text-align:center; font-weight: 700;"> FECHA </th>
        <th style="text-align:center; font-weight: 700;"> HORAS </th>
    </tr>
    </thead>
    <tbody>
    </tbody>
</table>
